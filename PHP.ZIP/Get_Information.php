<!DOCTYPE html>
<html>
<head>
<title>Website</title>
</head>
<body>
<form action="processform.php" method="post">Name
<p>
<label for="Input Name">Name</label> 
<input type="text">
</p>
<p>
<label for="Input Email">Email</label>
<input type="text">
</p>
<input type="submit">
<input type="reset">
</form>
</body>
</html>
