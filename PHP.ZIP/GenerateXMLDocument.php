<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php
$channel=array("link"=>'http://w3schools.com",description=>"Choose what to study");
print "<channel>";
foreach($channel as $key=>$val)
{
print($channel);
}
?>
</body>
</html>