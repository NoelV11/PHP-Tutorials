<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Website</title>
</head>
<body>
<ol>
<li>Name<?php $_GET["Name"] ?></li>
<li>Email<?php $_GET["Email"] ?></li>
</ol>
</body>
</html>